// The Grid component allows an element to be located
//  on a grid of tiles
Crafty.c('Grid', {
  init: function() {
    this.attr({
      w: Game.map_grid.tile.width,
      h: Game.map_grid.tile.height
    })
  },
 
  // Locate this entity at the given position on the grid
  at: function(x, y) {
    if (x === undefined && y === undefined) {
      return { x: this.x/Game.map_grid.tile.width, y: this.y/Game.map_grid.tile.height }
    } 
    else {
      this.attr({ x: x * Game.map_grid.tile.width, y: y * Game.map_grid.tile.height });
      return this;
    }
  }
});
 
// An "Actor" is an entity that is drawn in 2D on canvas
//  via our logical coordinate grid

// by calling the "Grid" attribute, it's pulling the function that we just declared on line 3
// it's automatically going to give it the same height and width of the tile declared on the 'Game' 
// variable that was declared on the game.js file

// An "Actor" is an entity that is drawn in 2D on canvas
//  via our logical coordinate grid

// it's basically the class that our components are extending below
Crafty.c('Actor', {
  init: function() {
    this.requires('2D, Canvas, Grid');
  },
});
 
// A Tree is just an Actor with a certain color
// it's adding the solid attribute to be able to trigger the Collision event
// it then gives it the image of the spr_tree file to use as it's identifier
// (previously we used the .color('rgb(20, 185, 40)') attribute)
Crafty.c('Tree', {
  init: function() {
    this.requires('Actor, Solid, spr_tree');
  },
});
 
// A Bush is just an Actor with a certain color
Crafty.c('Bush', {
  init: function() {
    this.requires('Actor, Solid, spr_bush');
  },
});

// A Rock is just an Actor with a certain sprite
Crafty.c('Rock', {
  init: function() {
    this.requires('Actor, Solid, spr_rock');
  },
});
 
// This is the player-controlled character
// the actor is part of the actor class which we created above, can move four ways,
// has a collision function that we assign to .stopsOnSolids() on line 65 (we create 
// this function on line 75) and uses the spr_player image
Crafty.c('PlayerCharacter', {
  init: function() {
    this.requires('Actor, Fourway, Collision, spr_player, SpriteAnimation')
      .fourway(4)
      .stopOnSolids()
      // Whenever the PC touches a village, respond to the event
      .onHit('Village', this.visitVillage)
      // These next lines define our four animations
      //  each call to .animate specifies:
      //  - the name of the animation
      //  - the x and y coordinates within the sprite
      //     map at which the animation set begins
      //  - the number of animation frames *in addition to* the first one
      // SO the 0, 0 means the x and y coordinates on the hunter.png sprite map file
      // and the animation will go through the images at 2 fps across the file to the right...
      .animate('PlayerMovingUp',    0, 0, 2)
      .animate('PlayerMovingRight', 0, 1, 2)
      .animate('PlayerMovingDown',  0, 2, 2)
      .animate('PlayerMovingLeft',  0, 3, 2);

      // Watch for a change of direction and switch animations accordingly
      // animation speed is how fast the character moves? ***********
      var animation_speed = 4;
      this.bind('NewDirection', function(data) {
        // this is declaring a new variable "NewDirection" and is checking which way they moved
        // if the x axis records that the player moved an additional space (or pixel) to the right,
        // it declares the variable "PlayerMovingRight" and inserts the speed variable declared on line 82
        if (data.x > 0) {
          this.animate('PlayerMovingRight', animation_speed, -1);
        } 
        else if (data.x < 0) {
          this.animate('PlayerMovingLeft', animation_speed, -1);
        } 
        else if (data.y > 0) {
          this.animate('PlayerMovingDown', animation_speed, -1);
        } 
        else if (data.y < 0) {
          this.animate('PlayerMovingUp', animation_speed, -1);
        } 
        else {
          // stop should be a built in function to stop the animation from continuing
          this.stop();
        }
      });
    },
 
  // Registers a stop-movement function to be called when
  // this entity hits an entity with the "Solid" component

  // this is saying whenever this function is being used with an entity that collides with 
  // a solid component, it will stop that entities movement (function being created on line 128).
  stopOnSolids: function() {
    this.onHit('Solid', this.stopMovement);
 
    return this;
  },
 
  // Stops the movement
  // the -= this._movement makes it so the character stops moving on contact.. If you change it
  // to +=, it will make the character go THROUGH that object at a faster walking rate.
  stopMovement: function() {
    this._speed = 0;
    if (this._movement) {
      this.x -= this._movement.x;
      this.y -= this._movement.y;
    }
  },

    // Respond to this player visiting a village
    // it's creating an array for perhaps the amount of villages the user visits, then it runs the
    // collect function, which erases that village from the map?
  visitVillage: function(data) {
    villlage = data[0].obj;
    villlage.visit();
  }
});

// A village is a tile on the grid that the PC must visit in order to win the game
Crafty.c('Village', {
  init: function() {
    this.requires('Actor, spr_village');
  },

  // Process a visitation with this village
  // the trigger function will initiate a callback function when this event happens
  // it helps to keep record of which villages we've already visited to help work towards ending the game
  // it plays the audio sound file that's declared on the scenes page
  visit: function() {
    this.destroy();
    Crafty.audio.play('knock');
    Crafty.trigger('VillageVisited', this);
  }
});