// GAME SCENE
// ------------------
// Runs the core gameplay Loop
// this is creating a specific clarified scene and giving it the name 'Game'
Crafty.scene('Game', function() {
  // A 2D array to keep track of all occupied tiles
  // the occupied function will keep track of which items on the stage are already occupied by a component
  // it's keeping one for width and another for height INSIDE the width so it can't overlap anything on the
  // x axis
  this.occupied = new Array(Game.map_grid.width);
  for (var i = 0; i < Game.map_grid.width; i++) {
    // this is looping through all avaiable tiles on the game and automatically setting them to NOT be occupied
    // the i variable in this case will be used for the x coordinate position
    // the y variable will be used for the y coordinate position
    // this will be usedful when we have to create elements and tell them to be occupied later
    this.occupied[i] = new Array(Game.map_grid.height);
    for (var y = 0; y < Game.map_grid.height; y++) {
      this.occupied[i][y] = false;
    }
  }
 
  // Player character, placed at 5, 5 on our grid
  this.player = Crafty.e('PlayerCharacter').at(5, 5);
  // telling the tile that the player starts on to be declared as OCCUPIED (setting occupied to TRUE)
  // declaring that the specific x and y coordinate are where the player is positioned at, and then puts 
  // that into the above i and y array...
  this.occupied[this.player.at().x][this.player.at().y] = true;
 
  // Place a tree at every edge square on our grid of 16x16 tiles
  // this gives it the green border all around the edge
  // first line is for width, second is for height
  for (var x = 0; x < Game.map_grid.width; x++) {
    for (var y = 0; y < Game.map_grid.height; y++) {
      // this is declaring variabe 'at_edge' to get all of the edge tiles
      // it checks to see if the x variable is at a 0 index (the top border across)
      // OR if it's at the bottom edge across by saying it's the width of the map area, minus one tile
      // OR if the same conditions apply to the Y axis
      var at_edge = x == 0 || x == Game.map_grid.width - 1 || 
                    y == 0 || y == Game.map_grid.height - 1;
 
      // if at_edge is true and set, then it will declare it as a 2D component, put it on the canvas
      // ("The Canvas component causes the entity to be drawn on the Canvas DOM element that displays our game."),
      // give that tile the position that it was found on the map (from using the for loops) and then give it 
      // the preexisting height/widths from line 7-9 where it says the size of the tile
      // it then gives it the dark green color
      if (at_edge) {
        // Place a tree entity at the current tile using the x and y variables in the for loop
        // the Tree variable comes from our components.js file
        Crafty.e('Tree').at(x, y);
        // setting the tile positioned at the current x and y coordinates to be declared as OCCUPIED (set as true)
        this.occupied[x][y] = true;
      } 
        // if it's NOT on the edge, it will pick a random number and if that number is less than 0.06, it will 
        // generate random bushes on the map at that location being called by the for loops
        // NOTE: it checks first to make sure that the space is NOT OCCUPIED
      else if (Math.random() < 0.06 && !this.occupied[x][y]) {
        // Places a bush or rock at the current position coordinates
        // This declares the bush_or_rock variable, it checks to see if the random chosen number in the math 
        // function is over 0.3, if it is, it will be true and thus create a bush on the map, if not it will 
        // make a rock
        var bush_or_rock = (Math.random() > 0.3) ? 'Bush' : 'Rock';
        Crafty.e(bush_or_rock).at(x, y);
        this.occupied[x][y] = true;
      }
    }
  }
 
  // Generate up to five villages on the map in random locations
  var max_villages = 5;
  for (var x = 0; x < Game.map_grid.width; x++) {
    for (var y = 0; y < Game.map_grid.height; y++) {
      if (Math.random() < 0.03) {
        // making sure that the number of villages already on the screen is less than 5 and that the space is 
        // NOT already occupied
        if (Crafty('Village').length < max_villages && !this.occupied[x][y]) {
          Crafty.e('Village').at(x, y);
        }
      }
    }
  }

  // Play a ringing sound to indicate the start of the journey
  Crafty.audio.play('ring');

  // declaring a new variable called VillageVisited and setting it to trigger the victory screen if
  // the variable 'village' does not have a length value anymore (so when all villages have been collected
  // and erased from the map)
  // 'bind' binds an entity to a global event
  this.show_victory = this.bind('VillageVisited', function() {
    if (!Crafty('Village').length) {
      Crafty.scene('Victory');
    }
  });
}, 

// this unbinds an element from the global scale and shows the victory screen
function() {
  this.unbind('VillageVisited', this.show_victory);
});
 

// Victory Scene
// -----------------
// Tells the player that they've won and lets them start a new game

// declares the Victory screen variable
  Crafty.scene('Victory', function() {
    Crafty.e('2D, DOM, Text')
      // this places the text victory message at the 0,0 coordinate on the stage
      .attr({x: 0, y: Game.height()/2 - 24, w: Game.width()})
      .text('All villages visited!')
      .css($text_css);
   
  // Give'em a round of applause!
  Crafty.audio.play('applause');


  // After a short delay, watch for the player to press a key, then restart
  // the game when a key is pressed
  var delay = true;
  setTimeout(function() { 
    delay = false;
    if (!delay) {
      Crafty.scene('Press');
    }
  }, 5000);
});


// Press Any Button Scene
// -----------------

  Crafty.scene('Press', function() {
    Crafty.e('2D, DOM, Text')
      // this places the text victory message at the 0,0 coordinate on the stage
      .attr({x: 0, y: Game.height()/2 - 24, w: Game.width()})
      .text('Press any key to play again')
      .css($text_css);

  // declares an event called 'restart_game' and binds the KeyDown variable globally and declares a function
  // to bring the game scene back up

  // "Watch for the player to press a key, then restart the game
  // when a key is pressed"
  this.restart_game = this.bind('KeyDown', function() {
    Crafty.scene('Game');
  });
}, 

// Remove our event binding from above so that we don't
// end up having multiple redundant event watchers after
// multiple restarts of the game
function() {
  this.unbind('KeyDown', this.restart_game);
});


// Loading scene
// -------------
// Handles the loading of binary assets such as images and audio files
// declares a variable called "Loading" and applies the following functions to it...
Crafty.scene('Loading', function(){
  // Draw some text for the player to see in case the file
  //  takes a noticeable amount of time to load
  Crafty.e('2D, DOM, Text')
    .text('Loading please wait...')
    // the x placer doesn't need to be set because we set the $text_css variable to automatically
    // put the text in the center of it's given area.
    // the height starts the text at the bottom of the game screen, then subtracts 24 pixels
    // the w placer makes the text take up the width of the game screen x axis
    .attr({ x: 0, y: Game.height()/2 - 24, w: Game.width() })
    .css($text_css);
 
  // Load our sprite map image and sounds from the assets folder
  Crafty.load(['assets/16x16_forest_2.gif',
                'assets/hunter.png',
                'assets/door_knock_3x.mp3',
                'assets/door_knock_3x.ogg',
                'assets/door_knock_3x.aac',
                'assets/board_room_applause.mp3',
                'assets/board_room_applause.ogg',
                'assets/board_room_applause.aac',
                'assets/candy_dish_lid.mp3',
                'assets/candy_dish_lid.ogg',
                'assets/candy_dish_lid.aac'], function(){
    // Once the image is loaded...
 
    // Define the individual sprites in the image
    // Each one (spr_tree, etc.) becomes a component
    // These components' names are prefixed with "spr_"
    //  to remind us that they simply cause the entity
    //  to be drawn with a certain sprite
    // the 16 in the parameter means that each sprite is 16 pixels high/wide
    Crafty.sprite(16, 'assets/16x16_forest_2.gif', {
      spr_tree:    [0, 0],
      spr_bush:    [1, 0],
      spr_village: [0, 1],
      spr_rock:    [1, 1]
    });
 
    // Define the PC's sprite to be the first sprite in the third row of the
    //  animation sprite map
    Crafty.sprite(16, 'assets/hunter.png', {
      spr_player:  [0, 2],
    }, 0, 2);

     // Define our sounds for later use
    Crafty.audio.add({
      knock:      ['assets/door_knock_3x.mp3',
                  'assets/door_knock_3x.ogg',
                  'assets/door_knock_3x.aac'], 
      applause:  ['assets/board_room_applause.mp3',
                  'assets/board_room_applause.ogg',
                  'assets/board_room_applause.aac'],
      ring:      ['assets/candy_dish_lid.mp3',
                  'assets/candy_dish_lid.ogg',
                  'assets/candy_dish_lid.aac']
    });
 
    // Now that our sprites are ready to draw, start the game
    Crafty.scene('Game');
  })
});