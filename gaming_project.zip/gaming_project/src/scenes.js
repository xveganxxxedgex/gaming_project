// GAME SCENE
// ------------------

Crafty.scene('Game', function() {
  Crafty.background("url('assets/ground_tile.gif')");
  this.occupied = new Array(Game.map_grid.width);
  for (var i = 0; i < Game.map_grid.width; i++) {
    this.occupied[i] = new Array(Game.map_grid.height);
    for (var y = 0; y < Game.map_grid.height; y++) {
      this.occupied[i][y] = false;
    }
  }

 
  // Player character, placed at 5, 5 on our grid
  this.player = Crafty.e('Bubsy').at(15, 0);
  this.occupied[this.player.at().x][this.player.at().y] = true;
  

  this.enemy = Crafty.e('Minotaur').at(9, 4); 
  this.occupied[this.enemy.at().x][this.enemy.at().y] = true;

  var move_right = 10;
  // var move_left = 10;
  function mino_move_right(move_right) {
    Crafty.e('Minotaur').move('e', move_right);
    move_right += 10;
  }

  // function mino_move_left() {
  //   Crafty.e('Minotaur').move('w', 10);
  // }

  setInterval(mino_move_right, 1000);
  // setInterval(mino_move_left, 1000);

  var time = 0;
  function countTime() {
    var html = "<p>" + time + "</p>";
    var target = document.getElementById("timer");
    target.innerHTML = html;
    time++;
  }

  setInterval(countTime, 1000);
 
  // Places the maze walls
  for (var x = 0; x < Game.map_grid.width; x++) {
    for (var y = 0; y < Game.map_grid.height; y++) {
      var top = ((x != 0) && (x != 15) && (x < Game.map_grid.width - 1)) && (y == 0);
      var bottom = ((x != 0) && (x < Game.map_grid.width - 1)) && (y == Game.map_grid.height - 1);
      var tleft_corner = (x == 0 && y == 0);
      var bleft_corner = ((x == 0) && (y == Game.map_grid.height - 1));
      var tright_corner = (x == Game.map_grid.width - 1 && y == 0);
      var bright_corner = (x == Game.map_grid.width - 1  && y == Game.map_grid.height - 1);
      var finish = (x == 15 && y == 1);
      if((x == 0) && ((y != 0) && (y != Game.map_grid.height - 1))) {
        Crafty.e('Maze_Left').at(x, y);
        this.occupied[x][y] = true;
      }
      else if ((x == Game.map_grid.width - 1) && ((y != 0) && (y != Game.map_grid.height - 1))) {
        Crafty.e('Maze_Right').at(x, y);
        this.occupied[x][y] = true;
      }
      else if (finish) {
        Crafty.e('Finish').at(x, y);
        this.occupied[x][y] = true;
      }
      else if (top) {
        Crafty.e('Maze_Top').at(x, y);
        this.occupied[x][y] = true;
      }
      else if (bottom) {
        Crafty.e('Maze_Bottom').at(x, y);
        this.occupied[x][y] = true;
      }
      else if (tleft_corner) {
        Crafty.e('Maze_TLeft').at(x, y);
        this.occupied[x][y] = true;
      }
      else if (bleft_corner) {
        Crafty.e('Maze_BLeft').at(x, y);
        this.occupied[x][y] = true;
      }
      else if (tright_corner) {
        Crafty.e('Maze_TRight').at(x, y);
        this.occupied[x][y] = true;
      }
      else if (bright_corner) {
        Crafty.e('Maze_BRight').at(x, y);
        this.occupied[x][y] = true;
      }
    }
  }

  for (var x = 0; x < Game.map_grid.width; x++) {
    for (var y = 0; y < Game.map_grid.height; y++) {
      if (x > 1 && x <= 6 && y == 2) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
      if ((x == 2) && y == 6) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
      if ((x >= 2 && x <= 6) && y == 7) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
      if ((x >= 1 && x <= 5) && y == 4) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
      if (x == 5 && y == 5) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      }
      if (x == 7 && y <= 7 && y != 0) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      }
      if (((x >= 11) && (x <= 12)) && (y == 4)) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
      if ((x == 9) && (y >= 6 && y <= 8)) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      }
      if (((x >= 9) && (x <= 13)) && (y == 2)) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      }  
      if ((x == 11) && ((y >= 5) && (y <= 7))) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
      if ((x == 13) && ((y == 3) || (y == 4) || (y == 6))) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      }  
      if (((x >= 11) && (x <= 17)) && (y == 7)) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      }  
      if ((x == 15) && ((y !== 0) && (y != 1) && (y <= 5))) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
      if ((x == 16) && (y == 5)) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
      if ((x == 17) && ((y <= 3 && y != 0) || (y == 5 && y != 0))) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
      if ((x == 18) && (y == 5 && y != 0)) {
        Crafty.e('Maze_Up').at(x, y);
        this.occupied[x][y] = true;
      } 
    }
  }


 
  // Generate up to five treats on the map in random locations
  var max_treats = 18;
  for (var x = 0; x < Game.map_grid.width; x++) {
    for (var y = 0; y < Game.map_grid.height; y++) {
      var new_sweet = Math.random();
      if (new_sweet < 0.05) {
        if (Crafty('Treat').length < max_treats && !this.occupied[x][y]) {
          if(new_sweet < 0.005) {
            Crafty.e('Mushmousse').at(x, y);
          }
          else if(new_sweet < 0.008) {
            Crafty.e('Pinkpie').at(x, y);
          }
          else if(new_sweet < 0.01) {
            Crafty.e('Tailpie').at(x, y);
          }
          else if(new_sweet < 0.013) {
            Crafty.e('Mushcake').at(x, y);
          }
          else if(new_sweet < 0.016) {
            Crafty.e('Lolli').at(x, y);
          }
          else if(new_sweet < 0.02) {
            Crafty.e('Candy').at(x, y);
          }
          else if(new_sweet < 0.023) {
            Crafty.e('House').at(x, y);
          }
          else if(new_sweet < 0.026) {
            Crafty.e('Ice').at(x, y);
          }
          else if(new_sweet < 0.029) {
            Crafty.e('Cherry').at(x, y);
          }
          else if(new_sweet < 0.032) {
            Crafty.e('Heartmousse').at(x, y);
          }
          else if(new_sweet < 0.035) {
            Crafty.e('Chocheart').at(x, y); 
          }
          else if(new_sweet < 0.038) {
            Crafty.e('Pinkmousse').at(x, y); 
          }
          else if(new_sweet < 0.041) {
            Crafty.e('Chocpie').at(x, y);
          }
          else if(new_sweet < 0.044) {
            Crafty.e('Mango').at(x, y);
          }
          else if(new_sweet < 0.047) {
            Crafty.e('Strawpie').at(x, y);
          }
          else if(new_sweet <= 0.05) {
            Crafty.e('Cookie').at(x, y);
          }
        }
      }
    }
  }

// console.log(Crafty.e('Chocpie'));
// console.log(Crafty.e('Bubsy')._x);
console.log(Crafty.e('Bubsy'));

  this.show_victory = this.bind('TreatObtained', function() {
    if (!Crafty('Treat').length && Crafty.e('Bubsy').isAt(15, 1)) {
      console.log(Crafty.e('Bubsy').isAt(15, 1));
      console.log('yes');
      Crafty.scene('Victory');
    }
    else {

    }

    // 
  });

  this.show_dead = this.bind('Kill', function() {
    if (alive = false) {
      Crafty.scene('Dead');
    }
  });
}, 

function() {
  this.unbind('TreatsObtained', this.show_victory);
});



// Loading scene
// -------------
// Handles the loading of binary assets such as images and audio files
// declares a variable called "Loading" and applies the following functions to it...
Crafty.scene('Loading', function(){
  // Draw some text for the player to see in case the file
  //  takes a noticeable amount of time to load
  Crafty.e('2D, DOM, Text')
    .text('Loading please wait...')
    // the x placer doesn't need to be set because we set the $text_css variable to automatically
    // put the text in the center of it's given area.
    // the height starts the text at the bottom of the game screen, then subtracts 24 pixels
    // the w placer makes the text take up the width of the game screen x axis
    .attr({ x: 0, y: Game.height()/2 - 24, w: Game.width() })
    .css($text_css);
 
  // Load our sprite map image and sounds from the assets folder
  Crafty.load(['assets/bubsy_sprites.gif',
                'assets/treats_white.gif',
                'assets/bubsy_sprites_close.gif',
                'assets/background_tiles.gif',
                'assets/mino_close.gif'], function(){
    // Once the image is loaded...
 
    // Define the individual sprites in the image
    // Each one (spr_tree, etc.) becomes a component
    // These components' names are prefixed with "spr_"
    //  to remind us that they simply cause the entity
    //  to be drawn with a certain sprite
    // the 16 in the parameter means that each sprite is 16 pixels high/wide
    Crafty.sprite(50, 'assets/background_tiles.gif', {
      spr_maze_bottom:    [0, 0],
      spr_maze_right:     [0, 1],
      spr_maze_trc:       [0, 2],
      spr_maze_left:      [1, 0],
      spr_floor:          [1, 1],
      spr_maze_tlc:       [1, 2],
      spr_maze_up:        [2, 0],
      spr_maze_brc:       [2, 1],
      spr_maze_blc:       [2, 2],
      spr_maze_top:       [3, 0]
    });

    Crafty.sprite(47, 'assets/bubsy_sprites_close.gif', {
      spr_bubsy_stand:   [0, 2]
    }, 7, 1);

    Crafty.sprite(47, 'assets/mino_close.gif', {
      spr_minotaur:   [0, 0]
    });

    Crafty.sprite(40, 'assets/treats_white.gif', {
      spr_mushmousse:    [0, 0],
      spr_pinkpie:       [1, 0],
      spr_tailpie:       [2, 0],
      spr_mushcake:      [3, 0],
      spr_lolli:         [4, 0],
      spr_candy:         [5, 0],
      spr_house:         [0, 1],
      spr_ice:           [1, 2],
      spr_cherry:        [2, 1],
      spr_fruit:         [3, 4],
      spr_heartmousse:   [4, 1],
      spr_chocheart:     [5, 1],
      spr_pinkmousse:    [1, 2],
      spr_chocpie:       [2, 2],
      spr_mango:         [3, 2],
      spr_strawpie:      [4, 2],
      spr_cookie:        [5, 2]
    }, 4);


     // Define our sounds for later use
    // Crafty.audio.add({
    //   knock:      ['assets/door_knock_3x.mp3',
    //               'assets/door_knock_3x.ogg',
    //               'assets/door_knock_3x.aac'], 
    //   applause:  ['assets/board_room_applause.mp3',
    //               'assets/board_room_applause.ogg',
    //               'assets/board_room_applause.aac'],
    //   ring:      ['assets/candy_dish_lid.mp3',
    //               'assets/candy_dish_lid.ogg',
    //               'assets/candy_dish_lid.aac']
    // });
 
    // Now that our sprites are ready to draw, start the game
    Crafty.scene('Game');
  })
});


// Victory Scene
// -----------------
// Tells the player that they've won and lets them start a new game

// declares the Victory screen variable
  Crafty.scene('Victory', function() {
    Crafty.e('2D, DOM, Text, Background')
      // this places the text victory message at the 0,0 coordinate on the stage
      .attr({x: 0, y: Game.height()/2 - 24, w: Game.width()})
      .text('You got all the treats!').css($text_css);
      Crafty.background('black');

  // After a short delay, watch for the player to press a key, then restart
  // the game when a key is pressed
  var delay = true;
  setTimeout(function() { 
    delay = false;
    if (!delay) {
      Crafty.scene('Press');
    }
  }, 3000);
});



// Press Any Button Scene
// -----------------

  Crafty.scene('Press', function() {
    Crafty.e('2D, DOM, Text')
      // this places the text victory message at the 0,0 coordinate on the stage
      .attr({x: 0, y: Game.height()/2 - 24, w: Game.width()})
      .text('Press any key to play again').css($text_css);
      Crafty.background('black');

  // declares an event called 'restart_game' and binds the KeyDown variable globally and declares a function
  // to bring the game scene back up

  // "Watch for the player to press a key, then restart the game
  // when a key is pressed"
  this.restart_game = this.bind('KeyDown', function() {
    Crafty.scene('Game');
  });
}, 

// Remove our event binding from above so that we don't
// end up having multiple redundant event watchers after
// multiple restarts of the game
function() {
  this.unbind('KeyDown', this.restart_game);
});


// Player Died Scene
// -----------------
// Tells the player that they've won and lets them start a new game

// declares the Victory screen variable
  Crafty.scene('Dead', function() {
    Crafty.e('2D, DOM, Text, Background')
      // this places the text victory message at the 0,0 coordinate on the stage
      .attr({x: 0, y: Game.height()/2 - 24, w: Game.width()})
      .text('The minotaur punched you and took all your treats!').css($text_css);
      Crafty.background('black');

  // After a short delay, watch for the player to press a key, then restart
  // the game when a key is pressed
  var delay = true;
  setTimeout(function() { 
    delay = false;
    if (!delay) {
      Crafty.scene('Again');
    }
  }, 3000);
});

// Press Any Button Scene
// -----------------

  Crafty.scene('Again', function() {
    Crafty.e('2D, DOM, Text')
      // this places the text victory message at the 0,0 coordinate on the stage
      .attr({x: 0, y: Game.height()/2 - 24, w: Game.width()})
      .text('Push any key to try again!').css($text_css);
      Crafty.background('black');

  // declares an event called 'restart_game' and binds the KeyDown variable globally and declares a function
  // to bring the game scene back up

  // "Watch for the player to press a key, then restart the game
  // when a key is pressed"
  this.restart_game = this.bind('KeyDown', function() {
    Crafty.scene('Game');
  });
}, 

// Remove our event binding from above so that we don't
// end up having multiple redundant event watchers after
// multiple restarts of the game
function() {
  this.unbind('KeyDown', this.restart_game);
});
